# File with sample functions.
def sum(x, y): # sums up two numbers
""" Adds two numbers.Returns the sum."""
return x + y

# Returns the product.
def mul(x, y):
# z is a local variable
z = x * y
return z