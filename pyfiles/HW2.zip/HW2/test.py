import math
y = math.sqrt(2)
print(y)